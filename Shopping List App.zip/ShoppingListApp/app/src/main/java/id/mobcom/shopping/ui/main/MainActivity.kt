package id.mobcom.shopping.ui.main

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import id.mobcom.shopping.R
import id.mobcom.shopping.databinding.ActivityMainBinding

/**
 * MainActivity
 *
 * Activity utama yang berfungsi sebagai container untuk navigasi antar fragment
 * menggunakan Navigation Component dan Bottom Navigation. Activity ini ditampilkan
 * setelah SplashScreen dan menangani perpindahan antar halaman utama aplikasi.
 */
class MainActivity : AppCompatActivity() {

    // Mendeklarasikan variable binding untuk mengakses view dalam layout
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mengaktifkan fitur edge-to-edge untuk tampilan fullscreen
        enableEdgeToEdge()

        // Menginisialisasi view binding dan mengatur layout activity
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Mengatur padding untuk system bars (status bar dan navigation bar)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Memanggil fungsi untuk mengatur bottom navigation
        setupBottomNavigation()
    }

    /**
     * Fungsi untuk mengatur Bottom Navigation dengan Navigation Component
     *
     * Fungsi ini menghubungkan BottomNavigationView dengan NavController
     * dan mengatur padding khusus untuk bottom navigation
     */
    private fun setupBottomNavigation() = binding.apply {
        // Mendapatkan NavHostFragment dari layout
        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment

        // Mendapatkan NavController dari NavHostFragment
        val navController = navHostFragment.navController

        // Menghubungkan BottomNavigationView dengan NavController
        bottomNavigationView.setupWithNavController(navController)

        // Mengatur padding bottom menjadi 0 untuk menghindari spacing berlebih
        bottomNavigationView.setOnApplyWindowInsetsListener { view, insets ->
            view.updatePadding(bottom = 0)
            insets
        }
    }
}
