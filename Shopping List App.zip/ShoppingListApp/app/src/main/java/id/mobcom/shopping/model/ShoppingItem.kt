package id.mobcom.shopping.model

import com.google.firebase.firestore.DocumentId
import java.util.Date

data class ShoppingItem(
    @DocumentId
    val id: String = "",
    val name: String = "",
    val category: String = "",
    val status: ItemStatus = ItemStatus.PENDING,
    val createdAt: Date = Date(),
    val updatedAt: Date = Date()
)
