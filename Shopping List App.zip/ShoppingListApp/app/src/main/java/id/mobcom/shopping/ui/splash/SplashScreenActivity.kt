package id.mobcom.shopping.ui.splash

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import id.mobcom.shopping.databinding.ActivitySplashScreenBinding
import id.mobcom.shopping.ui.main.MainActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@SuppressLint("CustomSplashScreen")
/**
 * SplashScreenActivity
 *
 * Activity ini berfungsi sebagai layar pembuka (splash screen) yang akan ditampilkan
 * saat aplikasi pertama kali dibuka. Activity ini akan menampilkan logo atau branding
 * aplikasi selama waktu yang ditentukan sebelum berpindah ke MainActivity.
 */
class SplashScreenActivity : AppCompatActivity() {

    // Mendeklarasikan variable binding untuk mengakses view dalam layout
    private lateinit var binding: ActivitySplashScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mengaktifkan fitur edge-to-edge untuk tampilan fullscreen
        enableEdgeToEdge()

        // Menginisialisasi view binding dan mengatur layout activity
        binding = ActivitySplashScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Mengatur padding system bars (status bar dan navigation bar) secara dinamis
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Memulai coroutine untuk menangani delay splash screen
        lifecycleScope.launch {
            // Menunda eksekusi selama waktu yang ditentukan (3 detik)
            delay(SPLASH_SCREEN_DELAY)

            // Berpindah ke MainActivity setelah delay selesai
            navigateToMainActivity()
        }
    }

    /**
     * Fungsi untuk berpindah ke MainActivity
     *
     * Fungsi ini membuat Intent baru untuk memulai MainActivity dengan flag yang
     * membersihkan stack activity sebelumnya
     */
    private fun navigateToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        // Mengatur flags untuk membersihkan stack activity dan membuat task baru
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
    }

    companion object {
        // Variabel constant untuk menentukan durasi tampilan splash screen (3 detik)
        private const val SPLASH_SCREEN_DELAY = 3000L
    }
}