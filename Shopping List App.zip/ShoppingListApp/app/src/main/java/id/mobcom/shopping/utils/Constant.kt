package id.mobcom.shopping.utils

/**
 * COLLECTION_SHOPPING_ITEMS
 *
 * Nama collection atau table untuk data daftar belanja
 */
const val COLLECTION_SHOPPING_ITEMS = "shopping_items"