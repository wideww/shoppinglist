package id.mobcom.shopping.ui.main

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.firestore.Filter
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import id.mobcom.shopping.R
import id.mobcom.shopping.adapter.ShoppingListAdapter
import id.mobcom.shopping.databinding.FragmentShoppingListBinding
import id.mobcom.shopping.model.ItemStatus
import id.mobcom.shopping.model.ShoppingItem
import id.mobcom.shopping.utils.COLLECTION_SHOPPING_ITEMS
import java.util.Date

/**
 * Fragment untuk menampilkan dan mengelola daftar belanja yang masih pending.
 */
class ShoppingListFragment : Fragment() {

    // Binding untuk mengakses view dalam layout
    private var _binding: FragmentShoppingListBinding? = null
    private val binding get() = _binding!!

    // Instance Firebase Firestore untuk operasi database
    private lateinit var firebaseFirestore: FirebaseFirestore

    // Adapter untuk menampilkan daftar belanja dalam RecyclerView
    private val shoppingListAdapter by lazy { ShoppingListAdapter() }

    // LiveData untuk mengelola status loading dan daftar belanja
    private val isLoading = MutableLiveData(false)
    private val shoppingList: MutableLiveData<List<ShoppingItem>> = MutableLiveData()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentShoppingListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Menginisialisasi Firebase Firestore
        firebaseFirestore = FirebaseFirestore.getInstance()

        // Setup UI, observer, dan mengambil data
        initView()
        observeData()
        fetchShoppingListData()
    }

    /**
     * Mengambil data daftar belanja dari Firebase Firestore
     * Hanya mengambil item dengan status PENDING dan diurutkan berdasarkan waktu pembuatan
     */
    private fun fetchShoppingListData() {
        // Mengaktifkan loading state
        isLoading.value = true

        // Query ke Firestore untuk mengambil data
        firebaseFirestore.collection(COLLECTION_SHOPPING_ITEMS)
            .where(Filter.equalTo("status", ItemStatus.PENDING))
            .orderBy("createdAt", Query.Direction.DESCENDING).get().addOnSuccessListener { result ->
                // Mengkonversi hasil query ke list ShoppingItem
                val list = result.toObjects(ShoppingItem::class.java)

                // Menghentikan loading state dan mengupdate daftar belanja
                shoppingList.value = list
                isLoading.value = false
            }.addOnFailureListener { exception ->
                Log.e(javaClass.simpleName, exception.message, exception)
                isLoading.value = false

                // Menampilkan pesan error dengan opsi untuk mencoba lagi
                showSnackbar(
                    getString(R.string.message_error), getString(R.string.action_try_again)
                ) {
                    fetchShoppingListData()
                }
            }
    }

    /**
     * Mengamati perubahan status loading dan daftar belanja untuk mengupdate UI
     */
    private fun observeData() {
        // Mengamati perubahan status loading untuk menampilkan/hilangkan progress bar
        isLoading.observe(viewLifecycleOwner) { isLoading ->
            binding.progressBar.isVisible = isLoading
        }

        // Mengamati perubahan daftar belanja untuk menampilkan item dalam RecyclerView
        shoppingList.observe(viewLifecycleOwner) { list ->
            // Menampilkan pesan jika daftar belanja kosong
            binding.emptyShoppingList.isVisible = list.isEmpty()

            // Mengirim data ke adapter untuk ditampilkan
            shoppingListAdapter.submitList(list)
        }
    }

    /**
     * Menampilkan pesan snackbar sederhana
     * @param message Pesan yang akan ditampilkan
     */
    private fun showSnackbar(message: String) =
        Snackbar.make(binding.main, message, Snackbar.LENGTH_SHORT).show()

    /**
     * Menampilkan pesan snackbar dengan tombol aksi
     * @param message Pesan yang akan ditampilkan
     * @param action Teks pada tombol aksi
     * @param listener Event listener untuk tombol aksi
     */
    private fun showSnackbar(message: String, action: String, listener: View.OnClickListener) {
        Snackbar.make(binding.main, message, Snackbar.LENGTH_LONG).setAction(action, listener)
            .show()
    }

    /**
     * Inisialisasi komponen UI dan setup event listener
     */
    private fun initView() = binding.apply {
        // Setup RecyclerView dan adapter
        rvShoppingList.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = shoppingListAdapter

            // Setup callback untuk aksi pada item
            shoppingListAdapter.onItemChecked = ::onItemChecked
            shoppingListAdapter.onItemDelete = ::onItemDelete
        }

        // Setup listener untuk tombol tambah item
        btnAddItem.setOnClickListener { navigateToAddItemFragment() }
    }

    /**
     * Navigasi ke fragment untuk menambah item baru
     */
    private fun navigateToAddItemFragment() {
        val action =
            ShoppingListFragmentDirections.actionNavigationShoppingListToNavigationAddItem()
        findNavController().navigate(action)
    }

    /**
     * Menangani penghapusan item dari daftar belanja
     * Menampilkan dialog konfirmasi sebelum menghapus
     * @param item Item yang akan dihapus
     */
    private fun onItemDelete(item: ShoppingItem) {
        // Mencegah multiple request saat loading
        if (isLoading.value == true) return

        // Membuat dan menampilkan dialog konfirmasi
        val alertDialog =
            AlertDialog.Builder(requireContext()).setTitle(getString(R.string.dialog_delete_title))
                .setMessage(getString(R.string.dialog_delete_message, item.name))
                .setPositiveButton(getString(R.string.action_delete)) { dialog, _ ->
                    // Menutup dialog
                    dialog.dismiss()

                    // Menampilkan loading state
                    isLoading.value = true

                    // Menghapus item dari Firestore
                    firebaseFirestore.collection(COLLECTION_SHOPPING_ITEMS).document(item.id)
                        .delete().addOnSuccessListener {
                            // Menampilkan pesan sukses
                            showSnackbar(getString(R.string.message_delete_success, item.name))

                            // Fetch data ulang setelah item dihapus
                            fetchShoppingListData()
                        }.addOnFailureListener { exception ->
                            Log.e(javaClass.simpleName, exception.message, exception)
                            isLoading.value = false

                            // Menampilkan pesan error dengan opsi untuk mencoba lagi
                            showSnackbar(
                                getString(R.string.message_error),
                                getString(R.string.action_try_again)
                            ) {
                                onItemDelete(item)
                            }
                        }
                }.setNegativeButton(getString(R.string.action_cancel)) { dialog, _ ->
                    dialog.dismiss()
                }.create()
        alertDialog.show()
    }

    /**
     * Menangani perubahan status item (dibeli/belum dibeli)
     * @param item Item yang statusnya diubah
     * @param isChecked Status baru item (true = sudah dibeli)
     */
    private fun onItemChecked(item: ShoppingItem, isChecked: Boolean) {
        // Mencegah multiple request saat loading
        if (isLoading.value == true) return
        // Menampilkan loading state
        isLoading.value = true

        // Menentukan status baru berdasarkan checkbox
        val status = if (isChecked) ItemStatus.BOUGHT else ItemStatus.PENDING

        // Mengupdate status item di Firestore
        firebaseFirestore.collection(COLLECTION_SHOPPING_ITEMS).document(item.id).update(
            mapOf(
                "status" to status,
                "updatedAt" to Date()
            )
        ).addOnSuccessListener {
            // Jika berhasil, menampilkan pesan sukses
            showSnackbar(
                getString(R.string.message_update_success, item.name),
                getString(R.string.action_see_item)
            ) {
                val action =
                    ShoppingListFragmentDirections.actionNavigationShoppingListToNavigationBoughtList()
                findNavController().navigate(action)
            }

            // Fetch data ulang setelah item diubah
            fetchShoppingListData()
        }.addOnFailureListener { exception ->
            // Jika gagal, menampilkan pesan error dengan opsi untuk mencoba lagi
            Log.e(javaClass.simpleName, exception.message, exception)
            isLoading.value = false

            showSnackbar(getString(R.string.message_error), getString(R.string.action_try_again)) {
                onItemChecked(item, isChecked)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}