package id.mobcom.shopping.ui.add_item

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import androidx.navigation.fragment.findNavController
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.firestore.FirebaseFirestore
import id.mobcom.shopping.R
import id.mobcom.shopping.databinding.FragmentAddItemBinding
import id.mobcom.shopping.model.ItemStatus
import id.mobcom.shopping.model.ShoppingItem
import id.mobcom.shopping.utils.COLLECTION_SHOPPING_ITEMS

/**
 * Fragment untuk menambahkan item belanja baru ke dalam daftar belanja.
 */
class AddItemFragment : Fragment() {

    // Binding untuk mengakses view dalam layout
    // Menggunakan property delegate untuk menghindari memory leak
    private var _binding: FragmentAddItemBinding? = null
    private val binding get() = _binding!!

    // Instance Firebase Firestore untuk operasi database
    private lateinit var firebaseFirestore: FirebaseFirestore

    // LiveData untuk mengelola status loading UI
    private val isLoading = MutableLiveData(false)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddItemBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Menginisialisasi Firebase Firestore
        firebaseFirestore = FirebaseFirestore.getInstance()

        // Setup UI dan observer
        initView()
        observeData()
    }

    /**
     * Inisialisasi komponen UI dan setup event listener
     */
    private fun initView() = binding.apply {
        // Setup dropdown kategori
        setupCategoryDropdown()

        // Menambahkan listener untuk button tambah item
        btnAddItem.setOnClickListener { addItem() }
    }

    /**
     * Menambahkan item baru ke Firebase Firestore
     * Melakukan validasi input sebelum penyimpanan
     */
    private fun addItem() {
        // Validasi input form
        if (validateInput()) {
            // Mengambil input dari form
            val itemName = binding.inputItemName.editText?.text.toString().trim()
            val category = binding.dropdownCategory.selectedItem.toString()

            // Mengaktifkan loading state
            isLoading.value = true

            // Membuat objek item baru
            val item = ShoppingItem(
                name = itemName,
                category = category,
                status = ItemStatus.PENDING
            )

            // Menyimpan item ke Firestore
            firebaseFirestore.collection(COLLECTION_SHOPPING_ITEMS)
                .add(item)
                .addOnSuccessListener {
                    // Reset UI setelah berhasil
                    isLoading.value = false
                    resetForm()

                    // Menampilkan pesan sukses dan opsi untuk melihat item
                    showSnackbar(
                        getString(R.string.message_item_added), getString(R.string.action_see_item)
                    ) {
                        // Navigasi ke fragment shopping list
                        val action =
                            AddItemFragmentDirections.actionNavigationAddItemToNavigationShoppingList()
                        findNavController().navigate(action)
                    }
                }.addOnFailureListener { exception ->
                    // Tampilkan exception pada log
                    Log.e(javaClass.simpleName, exception.message, exception)

                    // Menghentikan loading state
                    isLoading.value = false

                    // Menampilkan pesan error dengan opsi untuk mencoba lagi
                    showSnackbar(
                        getString(R.string.message_error),
                        getString(R.string.action_try_again)
                    ) {
                        addItem()
                    }
                }
        }
    }

    /**
     * Memvalidasi input form sebelum penyimpanan
     * @return Boolean true jika input valid, false jika tidak
     */
    private fun validateInput(): Boolean {
        // Mengambil input dari form
        val itemName = binding.inputItemName.editText?.text.toString().trim()
        val category = binding.dropdownCategory.selectedItem.toString()
        var isValid = true

        // Validasi nama item tidak boleh kosong
        if (itemName.isBlank()) {
            binding.inputItemName.error =
                getString(R.string.error_empty_field, getString(R.string.label_item_name))
            isValid = false
        }

        // Validasi kategori harus dipilih
        if (category == getString(R.string.select_category)) {
            showSnackbar(getString(R.string.error_select_category))
            isValid = false
        }

        return isValid
    }

    /**
     * Mengatur ulang form ke kondisi awal
     */
    private fun resetForm() = binding.apply {
        // Menghapus text pada input name
        inputItemName.editText?.text?.clear()

        // Mengatur dropdown ke posisi awal
        dropdownCategory.setSelection(0)
    }

    /**
     * Menampilkan pesan snackbar sederhana
     * @param message Pesan yang akan ditampilkan
     */
    private fun showSnackbar(message: String) =
        Snackbar.make(binding.main, message, Snackbar.LENGTH_SHORT).show()

    /**
     * Menampilkan pesan snackbar dengan tombol aksi
     * @param message Pesan yang akan ditampilkan
     * @param action Teks pada tombol aksi
     * @param listener Event listener untuk tombol aksi
     */
    private fun showSnackbar(message: String, action: String, listener: View.OnClickListener) {
        Snackbar.make(binding.main, message, Snackbar.LENGTH_LONG).setAction(action, listener)
            .show()
    }

    /**
     * Setup dropdown untuk pemilihan kategori item
     */
    private fun setupCategoryDropdown() {
        // Mengambil array kategori dari resources
        val categories = resources.getStringArray(R.array.item_categories)

        // Membuat adapter untuk dropdown dengan layout custom
        val adapter = ArrayAdapter(requireContext(), R.layout.item_dropdown, categories)

        // Mengatur adapter ke dropdown
        binding.dropdownCategory.adapter = adapter
    }

    /**
     * Mengamati perubahan status loading untuk mengupdate UI
     */
    private fun observeData() {
        // Mengamati status loading
        // Fungsi akan dipanggil setiap value isLoading berubah
        isLoading.observe(viewLifecycleOwner) { isLoading ->
            // Mengupdate visibility dan state komponen berdasarkan status loading
            binding.progressBar.isVisible = isLoading
            binding.btnAddItem.isEnabled = !isLoading
            binding.inputItemName.isEnabled = !isLoading
            binding.dropdownCategory.isEnabled = !isLoading
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}