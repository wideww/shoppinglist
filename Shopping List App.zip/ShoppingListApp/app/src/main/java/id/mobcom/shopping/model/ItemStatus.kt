package id.mobcom.shopping.model

enum class ItemStatus {
    PENDING,
    BOUGHT;

    override fun toString(): String {
        return when (this) {
            PENDING -> "Pending"
            BOUGHT -> "Sudah Dibeli"
        }
    }
}