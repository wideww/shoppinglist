package id.mobcom.shopping.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import id.mobcom.shopping.databinding.ItemShoppingListBinding
import id.mobcom.shopping.model.ItemStatus
import id.mobcom.shopping.model.ShoppingItem

/**
 * Adapter untuk menampilkan daftar item belanja dalam RecyclerView.
 * Menggunakan ListAdapter untuk menangani perubahan data yang efisien dengan DiffUtil.
 */
class ShoppingListAdapter : ListAdapter<ShoppingItem, ShoppingListAdapter.ViewHolder>(
    DIFF_CALLBACK
) {
    /**
     * Callback untuk menangani penghapusan item
     * Akan dipanggil saat button delete diklik
     */
    var onItemDelete: ((ShoppingItem) -> Unit)? = null
    /**
     * Callback untuk menangani perubahan status item (checked/unchecked)
     * Akan dipanggil saat checkbox diklik
     */
    var onItemChecked: ((ShoppingItem, Boolean) -> Unit)? = null

    /**
     * Membuat ViewHolder baru untuk setiap item dalam list
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemShoppingListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    /**
     * Menghubungkan data dengan ViewHolder
     */
    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    inner class ViewHolder(private val binding: ItemShoppingListBinding) : RecyclerView.ViewHolder(binding.root) {

        /**
         * Mengisi data ke dalam view
         */
        fun bind(item: ShoppingItem) {
            binding.apply {
                // Menampilkan informasi item
                tvName.text = item.name
                tvCategory.text = item.category
                tvStatus.text = item.status.toString()

                // Mengatur centang pada checkbox sesuai status item
                cbBought.isChecked = item.status == ItemStatus.BOUGHT

                // Menghilangkan checkbox saat item sudah dibeli
                cbBought.isVisible = item.status != ItemStatus.BOUGHT

                // Menangani saat button delete diklik
                btnDelete.setOnClickListener {
                    onItemDelete?.invoke(item)
                }

                // Menangani perubahan status checkbox
                cbBought.setOnCheckedChangeListener { _, isChecked ->
                    onItemChecked?.invoke(item, isChecked)
                }
            }
        }
    }

    companion object {
        // DiffUtil untuk membandingkan item lama dan baru
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ShoppingItem>() {
            override fun areItemsTheSame(oldItem: ShoppingItem, newItem: ShoppingItem): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: ShoppingItem, newItem: ShoppingItem): Boolean {
                return oldItem.hashCode() == newItem.hashCode()
            }
        }
    }
}
