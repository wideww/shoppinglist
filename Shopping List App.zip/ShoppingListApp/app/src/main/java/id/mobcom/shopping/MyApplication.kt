package id.mobcom.shopping

import android.app.Application
import com.google.firebase.Firebase
import com.google.firebase.initialize

/**
 * MyApplication
 *
 * Kelas ini merupakan kelas Application utama yang digunakan untuk melakukan
 * inisialisasi komponen-komponen utama aplikasi saat pertama kali dijalankan.
 * Kelas ini harus didaftarkan di AndroidManifest.xml dengan nama android:name=".MyApplication"
 */
class MyApplication : Application() {

    // Override fungsi onCreate yang akan dipanggil saat aplikasi pertama kali dibuat
    override fun onCreate() {
        // Memanggil implementasi onCreate dari parent class
        super.onCreate()

        // Melakukan inisialisasi Firebase SDK dengan context aplikasi
        // Ini diperlukan sebelum menggunakan layanan Firebase apapun dalam aplikasi
        Firebase.initialize(applicationContext)
    }
}